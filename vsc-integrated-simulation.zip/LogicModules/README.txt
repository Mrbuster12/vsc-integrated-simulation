This folder is for LogicModules assets.
