This folder is for Scenarios assets.
