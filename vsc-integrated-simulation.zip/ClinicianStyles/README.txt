This folder is for ClinicianStyles assets.
