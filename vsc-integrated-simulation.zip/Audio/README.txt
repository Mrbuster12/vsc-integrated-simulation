This folder is for Audio assets.
